//
//  CoreDataClassPost.swift
//  TestMediSage
//
//  Created by NIKHIL KISHOR PATIL on 27/04/21.
//

import Foundation
import CoreData

@objc(Post)
public class Post: NSManagedObject {

}
