//
//  PostModel.swift
//  TestMediSage
//
//  Created by NIKHIL KISHOR PATIL on 27/04/21.
//

import Foundation

class PostModel: NSObject {
    
    var id : Int?
    var title : String?
    var explanation : String?
    
}
